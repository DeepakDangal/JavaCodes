package com.example.csd214deepak_dangal.Model;

public class Test {
  private int id;
  private String name;

    public Test(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

}